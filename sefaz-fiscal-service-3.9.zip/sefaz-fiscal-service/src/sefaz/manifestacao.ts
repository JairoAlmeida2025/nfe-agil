import { assinarXML } from './signer'
import { callSefaz } from './client'
import fs from 'fs'

// Endpoint Nacional de Recepção de Evento (Destinada)
const ENDPOINT_EVENTO = 'https://www.nfe.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx'
// Em ambientes Nacionais, no SOAP 1.2 a action deve ser vazia no header
const SOAP_ACTION_EVENTO = ''

function getDhEvento() {
  // Retorna data atual no formato AAAA-MM-DDThh:mm:ss-03:00 (Brasília)
  // Ajuste simples para node
  const now = new Date()
  now.setHours(now.getHours() - 3) // Ajusta fuso (simples)
  return now.toISOString().slice(0, 19) + '-03:00'
}

export async function enviarManifestacao(cnpj: string, chave: string, pfx: Buffer, passphrase: string, tipoEvento: string = '210210'): Promise<{ cStat: string, xMotivo: string, xmlRetorno: string }> {
  const idLote = '1'
  const seqEvento = '1'
  const nSeqEvento = '1'
  const verEvento = '1.00'
  const id = `ID${tipoEvento}${chave}0${seqEvento}`
  const dhEvento = getDhEvento()

  let descEvento = 'Ciencia da Operacao'
  if (tipoEvento === '210200') descEvento = 'Confirmacao da Operacao'
  else if (tipoEvento === '210220') descEvento = 'Desconhecimento da Operacao'
  else if (tipoEvento === '210240') descEvento = 'Operacao nao Realizada'

  // XML do Evento (que será assinado)
  const xmlEvento = `<evento xmlns="http://www.portalfiscal.inf.br/nfe" versao="${verEvento}">
<infEvento Id="${id}">
<cOrgao>91</cOrgao>
<tpAmb>1</tpAmb>
<CNPJ>${cnpj}</CNPJ>
<chNFe>${chave}</chNFe>
<dhEvento>${dhEvento}</dhEvento>
<tpEvento>${tipoEvento}</tpEvento>
<nSeqEvento>${nSeqEvento}</nSeqEvento>
<verEvento>${verEvento}</verEvento>
<detEvento version="${verEvento}">
<descEvento>${descEvento}</descEvento>
</detEvento>
</infEvento>
</evento>`

  // Assinar
  if (!pfx || !passphrase) throw new Error('Credenciais PFX faltando')

  let xmlAssinado = ''
  try {
    xmlAssinado = assinarXML(xmlEvento, id, pfx, passphrase)
  } catch (e) {
    console.error('Erro na assinatura digital: e')
    throw new Error(`Falha ao assinar evento: ${String(e)}`)
  }

  // Envelope de Envio (envEvento) - Retornado para SOAP 1.2 com Action vazia conforme recomendação
  const xmlEnvio = `<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
  <soap12:Body>
    <nfeDadosMsg xmlns="http://www.portalfiscal.inf.br/nfe/wsdl/NFeRecepcaoEvento4">
      <envEvento xmlns="http://www.portalfiscal.inf.br/nfe" versao="1.00">
        <idLote>${idLote}</idLote>
        ${xmlAssinado}
      </envEvento>
    </nfeDadosMsg>
  </soap12:Body>
</soap12:Envelope>`

  // Enviar (passando credenciais)
  const xmlRetorno = await callSefaz(xmlEnvio, pfx, passphrase, ENDPOINT_EVENTO, SOAP_ACTION_EVENTO)

  // Parse Resposta Simplificado (Regex)
  const matchStat = xmlRetorno.match(/<cStat>(\d+)<\/cStat>/) || []
  const matchMotivo = xmlRetorno.match(/<xMotivo>([^<]+)<\/xMotivo>/) || []

  const cStat = matchStat[1] || ''
  const xMotivo = matchMotivo[1] || ''

  return { cStat, xMotivo, xmlRetorno }
}
